using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
public class Player : MonoBehaviour
{
    enum State
    {
        Idle, Run, Jump, WallJump, Fall, DoubleJump, Attack
    }
    [SerializeField] private float jumpForce;
    [SerializeField] private float speedRun;
    [SerializeField] private Physics2D ps2D;

    private Vector2 prePos;
    private int jumpAgain;
    private bool isOnGround;
    private Rigidbody2D rgbody;
    private Animator animator;
    private State curState;
    private InputCtrler playerInput;
    private Vector2 movePlayer;

    private void OnEnable()
    {
        if (playerInput == null)
        {
            playerInput = new InputCtrler();
            playerInput.Player.Movement.started += OnMovement;
            playerInput.Player.Movement.performed += OnMovement;
            playerInput.Player.Movement.canceled += OnMovement;
            playerInput.Player.Attack.started += OnAttack;
            playerInput.Player.Attack.performed += OnAttack;
            playerInput.Player.Attack.canceled += OnAttack;
            playerInput.Player.Jump.started += OnJump;
            playerInput.Player.Jump.performed += OnJump;
            playerInput.Player.Jump.canceled += OnJump;
        }
        playerInput.Enable();
    }
    // Start is called before the first frame update
    void Start()
    {
        rgbody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        prePos = transform.position;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (movePlayer == Vector2.zero && isOnGround)
        {
            PlayAni(State.Idle);
            rgbody.velocity = new Vector2(movePlayer.x * speedRun, rgbody.velocity.y);
            return;
        }
        Move();

    }
    private void SetDirection()
    {
        if (movePlayer.x < 0)
        {
            transform.rotation = Quaternion.AngleAxis(180, Vector3.up);
        }
        else if (movePlayer.x > 0)
        {
            transform.rotation = Quaternion.AngleAxis(0, Vector3.zero);
        }
    }
    private void Move()
    {
        SetDirection();
        if (!isOnGround && jumpAgain == 2)
        {
            PlayAni(State.DoubleJump);
        }
        else if (!isOnGround && movePlayer.x != 0)
        {
            PlayAni(State.WallJump);
        }
        else if (!isOnGround && transform.position.y >= prePos.y)
        {
            PlayAni(State.Jump);
        }
        else if (isOnGround && movePlayer.x != 0)
        {
            PlayAni(State.Run);
        }
        else
        {
            PlayAni(State.Fall);
        }
        prePos = transform.position;
        rgbody.velocity = new Vector2(movePlayer.x * speedRun, rgbody.velocity.y);
    }
    private void OnAttack(InputAction.CallbackContext obj)
    {
        if (obj.started)
        {

        }
        else if (obj.performed)
        {

        }
        else if (obj.canceled)
        {

        }
    }

    private void OnMovement(InputAction.CallbackContext obj)
    {
        if (obj.performed)
        {
            movePlayer = obj.ReadValue<Vector2>();
        }
        else
        {
            movePlayer = Vector2.zero;
        }
    }
    private void OnJump(InputAction.CallbackContext obj)
    {
        if (obj.performed)
        {
            if (isOnGround || jumpAgain < 2)
            {
                jumpAgain++;
                isOnGround = false;
                rgbody.velocity = new Vector2(rgbody.velocity.x, jumpForce);
                PlayAni(State.Jump);
                AudioManager.instance.PlayAudio("jump");
            }
        }
        else
        {

        }
    }
    private void PlayAni(State state)
    {

        if (curState == state)
            return;
        animator.SetInteger("State", (int)state);
        animator.SetTrigger("Change");
        curState = state;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground") && collision.otherCollider.name != "Foot")
        {
            Debug.Log(collision.otherCollider.name);
            jumpAgain = 0;
            isOnGround = true;
        }

    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Fruit"))
        {
            if (collision.TryGetComponent(out Transform a))
            {
                Destroy(a.gameObject);
                AudioManager.instance.PlayAudio("earn");
                UIManager.instance.Score();
            }
        }
    }
    //private void OnCollisionExit2D(Collision2D collision)
    //{
    //    if (collision.collider.CompareTag("Ground"))
    //    {
    //        isOnGround = false;
    //    }
    //}
}
