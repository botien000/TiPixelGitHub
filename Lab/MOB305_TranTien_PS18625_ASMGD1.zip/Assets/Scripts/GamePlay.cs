using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class GamePlay : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI txtCore;
    [SerializeField] private GameObject[] hearts;
    private int curScore;
    // Start is called before the first frame update
    void Start()
    {
        curScore = 0;
        ShowTextScore(curScore);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public int IncrScore()
    {
        return ++curScore;
    }
    public void ShowTextScore(int score)
    {
        Debug.Log(score);
        txtCore.text = "x" + score;
    }
    public void ToSetting()
    {
        UIManager.instance.ToGameSetting();
    }
}
