using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    enum State
    {
        GamePlay,GameSetting
    }
    private State curState;
    [SerializeField]
    private GamePlay gamePlay;
    [SerializeField]
    private GameSetting gameSetting;
    public static UIManager instance;

    private void Awake()
    {
        if(instance == null)
        {
            
            instance = this;
        }
    }
    private void OnEnable()
    {
    }
    // Start is called before the first frame update
    void Start()
    {
        StateGame(State.GamePlay);
    }
    public void Score()
    {
        gamePlay.ShowTextScore(gamePlay.IncrScore());
    }
    public void ToGameSetting()
    {
        StateGame(State.GameSetting);
    }
    public void ToGamePlay()
    {
        StateGame(State.GamePlay);
        Time.timeScale = 1;
    }
    private void StateGame(State state)
    {
        curState = state;
        bool isActiveGamePlay = curState == State.GamePlay ? true : false;
        gamePlay.gameObject.SetActive(isActiveGamePlay);
        gameSetting.gameObject.SetActive(!isActiveGamePlay);
    }
}
