using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GameSetting : MonoBehaviour
{
    [SerializeField] private Sprite[] spriteMusic;
    [SerializeField] private Image imgMusic;

    private int amountPress;
    private void OnEnable()
    {
        Time.timeScale = 0f;
    }
    public void BtnResume()
    {
        UIManager.instance.ToGamePlay();
    }
    public void BtnRestart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void BtnHome()
    {

    }
    public void BtnMusic()
    {
        amountPress++;
        if(amountPress == 1)
        {
            //mute 
            AudioManager.instance.curSound.audioSource.mute = true;
            imgMusic.sprite = spriteMusic[1];
        }
        else
        {
            //open
            AudioManager.instance.curSound.audioSource.mute = false;
            imgMusic.sprite = spriteMusic[0];
            amountPress = 0;
        }

    }
}
