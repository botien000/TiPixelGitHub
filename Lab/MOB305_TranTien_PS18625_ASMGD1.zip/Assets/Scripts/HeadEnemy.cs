using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeadEnemy : MonoBehaviour
{
    private Enemy parentEnemy;
    private void OnEnable()
    {
        if(parentEnemy == null)
        {
            parentEnemy = GetComponentInParent<Enemy>();
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            parentEnemy.Hit();
        }
    }

}
