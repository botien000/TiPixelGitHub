using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireHeartScript : MonoBehaviour
{
    public new Rigidbody2D rigidbody2D;
    public Vector2 velocity;

    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject, 10);
        rigidbody2D = GetComponent<Rigidbody2D>();
        //velocity = new Vector2(5, -5);
    }

    // Update is called once per frame
    void Update()
    {
        if (velocity == null) return;
        if (rigidbody2D.velocity.y < velocity.y)
        {
            rigidbody2D.velocity = velocity;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        rigidbody2D.velocity = new Vector2(velocity.x, -velocity.y);
        if (collision.contacts[0].normal.x != 0)
        {
            Destroy(gameObject);
        }
    }
    public void SetVelocity(Vector2 v)
    {
        velocity = v;

    }
}
