using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire : MonoBehaviour
{
    [SerializeField] private GameObject vfx;
    [SerializeField] private float speedRoll;
    private Rigidbody2D rgbody2D;
    private float dirX;
    // Start is called before the first frame update
    void Start()
    {
        rgbody2D = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        rgbody2D.velocity = new Vector2(speedRoll * dirX, rgbody2D.velocity.y);
        //rgbody2D.AddForce(new Vector2(speedRoll * Time.fixedDeltaTime, 0), ForceMode2D.Impulse);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Enemy") || collision.CompareTag("Wall") || collision.CompareTag("Conduit"))
        {
            Destroy(gameObject);
            Destroy(Instantiate(vfx, transform.position, Quaternion.identity), 0.5f);

        }
    }
    public void SetDir(float x)
    {
        dirX = x;
    }

}
